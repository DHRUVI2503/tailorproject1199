import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ApiService {

  apiurl = "http://localhost:8081/";

  constructor(private http:HttpClient) { 

  }

  RegisterUser(inputdata:any){
    return this.http.post(this.apiurl + "Register", inputdata)
  }

  login(inputdata:any){
    return this.http.post(this.apiurl + "Login", inputdata)
  }
  GetUserbyCode(id:any){
    return this.http.get(this.apiurl+'/'+id);
  }
  Getall(){
    return this.http.get(this.apiurl);
  }
  updateuser(id:any,inputdata:any){
    return this.http.put(this.apiurl+'/'+id,inputdata);
  }
  getuserrole(){
    return this.http.get('http://localhost:8081/role');
  }
  isloggedin(){
    return sessionStorage.getItem('username')!=null;
  }
  getrole(){
    return sessionStorage.getItem('role')!=null?sessionStorage.getItem('role')?.toString():'';
  }
  GetAllUser(){
    return this.http.get('http://localhost:8081/user');
  }
  Getaccessbyrole(role:any,menu:any){
    return this.http.get('http://localhost:8081/roleaccess?role='+role+'&menu='+menu)
  }
  post(path:string, data:any){
    const headers = {'Content-type':'application/json'};
    const body = JSON.stringify(data);
    console.log("this",this.apiurl);
    return this.http.post(this.apiurl + path, body, {'headers':headers});
  }
}
