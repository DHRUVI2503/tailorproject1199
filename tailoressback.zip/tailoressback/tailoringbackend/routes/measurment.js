let express = require("express");
let bodyparser = require("body-parser");
let Measurment = require("../models/Measurment");


let router = express.Router();

router.post("/Measurment", async (req, res) => {
    try {
        let body = req.body;
        let measurment = new Measurment();

        let measurments = await Measurment.find({ name: body.data.name });
        if (measurments.length != 0) {
            res.end(JSON.stringify({ status: "failed", data: "name is already exist" }));
        }
        measurments = await Measurment.find({ srno: body.data.weight });
        if (measurments.length != 0) {
            res.end(JSON.stringify({ status: "failed", data: "weight is already exist" }));
        }
        measurment.name = body.data.name;
        measurment.products = body.data.products;
        measurment.Height = body.data.height;
        measurment.weight = body.data.weight;
        measurment.wrist = body.data.wrist;
        measurment.shoulder = body.data.shoulder;
        measurment.chest = body.data.chest;
        measurment.waist = body.data.weist;
        measurment.inseam= body.data.inseam;
        measurment.outseam = body.data.outseam;

        measurment.save().then(result => {
            res.end(JSON.stringify({ status: "success", data: result }));
        }, err => {
            res.end(JSON.stringify({ status: "failed", data: err }));
        });
    }
    catch {
        res.end(JSON.stringify({ status: "failed", data: "Something went wrong" }));
    }
});


router.post("/measurments", async (req, res) => {
    try {
        let body = req.body;
        let measurments = await Measurment.find({ name: body.data.name });
        res.end(JSON.stringify({ status: "success", data: measurments }));
    }
    catch {
        res.end(JSON.stringify({ status: "failed", data: "Something went wrong" }));
    }
});

module.exports = router;